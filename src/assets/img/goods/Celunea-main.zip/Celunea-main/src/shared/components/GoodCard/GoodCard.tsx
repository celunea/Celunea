import React from "react";
import { GoodInterface } from "../../../constants/interfaces/goodInterface";
import styles from "./GoodCard.module.css";
import { NavLink } from "react-router-dom";
import { Routes } from "../../../constants/enums/routes";

interface Props {
  good: GoodInterface;
}

const GoodCard: React.FC<Props> = ({ good }) => {
  return (
    <>
      <NavLink className={styles.mainWrapper} to={`${Routes.GOOD}/${good.id}`}>
        <div className={styles.wrapper}>
          <img src={good.imgUrl} className={styles.goodImage} />
          <p className={styles.goodName}>{good.title}</p>
          <div className={styles.bottomWrapper}>
            <p className={styles.priceText}>{good.price} грн.</p>
            <NavLink
              to={`${Routes.GOOD}/${good.id}`}
              className={styles.buyButton}
            >
              Купити
            </NavLink>
          </div>
        </div>
      </NavLink>
    </>
  );
};
export default GoodCard;
