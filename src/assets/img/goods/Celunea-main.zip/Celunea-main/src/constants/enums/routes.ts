export enum Routes {
  HELLO = "/",
  MAIN = "/main",
  ABOUTUS = "/aboutus",
  CATEGORIES = "/categories",
  CONTACTS = "/contacts",
  GOOD = "/goods",
}
