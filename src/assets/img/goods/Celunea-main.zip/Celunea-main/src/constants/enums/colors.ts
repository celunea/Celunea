export enum Color {
  DARK_BLUE = "#101624",
  LIGHT_BLUE = "#aab4b8",
  TEXT_COLOR_BANNER = "#21293b",
  WHITE = "white",
}
