import { useParams } from "react-router-dom";
import styles from "./GoodPage.module.css";
import { useEffect, useState } from "react";
import { GoodInterface } from "../../constants/interfaces/goodInterface";
import { getGoodById } from "../../shared/services/goodsService";

const GoodPage: React.FC = () => {
  const [good, setGood] = useState<GoodInterface>();
  const { id } = useParams();
  useEffect(() => {
    const foundedGood = getGoodById(Number(id));
    setGood(foundedGood);
    console.log(foundedGood);
  }, [id]);
  return (
    <>
      <div className={styles.mainWrapper}>
        <div className={styles.contentWrapper}>
          <h1 className={styles.header}>{good?.title}</h1>
          <div className={styles.wrappers}>
            <div className={styles.leftWrapper}>
              <img src={good?.imgUrl} className={styles.image} />
            </div>
            <div className={styles.rightWrapper}>
              <h3 className={styles.price}>{good?.price} грн.</h3>
              <hr />
              <div className={styles.details}>
                <h1 className={styles.headerOfDescription}>Характеристики</h1>
                {good?.details.map((e) => (
                  <>
                    <div className={styles.detail}>
                      <h5 className={styles.titleOfDetail}>{e.title}</h5>
                      <p className={styles.valueOfDetail}>{e.value}</p>
                    </div>
                  </>
                ))}
              </div>
              <hr />
              <div className={styles.description}>
                <h1 className={styles.headerOfDescription}>Опис</h1>
                <p className={styles.valueOfDetail}>{good?.description}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default GoodPage;
