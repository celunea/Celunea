import React, { useEffect } from "react";
import { useLocation } from "react-router-dom";
import NavBar from "../shared/components/NavBar/NavBar";
import Footer from "../shared/components/Footer/Footer";

type Props = {
  children: React.ReactNode;
};

export const Layout: React.FC<Props> = ({ children }) => {
  const location = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);
  return (
    <>
      <NavBar />
      <div style={{ marginTop: 100 }}>{children}</div>
      <Footer />
    </>
  );
};
